import cv2

class EyeTracking(object):
    
    def __init__(self, face_haarcascade, eye_haarcascade):
        self.face_haarcascade_file = cv2.CascadeClassifier(face_haarcascade)
        self.eye_haarcascade_file = cv2.CascadeClassifier(eye_haarcascade)

    def tracking(self, image):
        faceCoordinates = self.face_haarcascade_file.detectMultiScale(image,
                                                             scaleFactor=1.8,
                                                             minNeighbors=5,
                                                             minSize=(30, 30),
                                                             flags=cv2.CASCADE_SCALE_IMAGE)

        faceAndEyeRectangles = []

        for (xCoordinateOfFace, yCoordinateOfFace, widthOfFace, heigthOfFace) in faceCoordinates:
            face_location_area = image[yCoordinateOfFace: yCoordinateOfFace + widthOfFace, xCoordinateOfFace: xCoordinateOfFace + widthOfFace]
            faceAndEyeRectangles.append((xCoordinateOfFace, yCoordinateOfFace, xCoordinateOfFace + widthOfFace, yCoordinateOfFace + widthOfFace))

            eyeCoordinate = self.eye_haarcascade_file.detectMultiScale(face_location_area,
                                                               scaleFactor=1.1,
                                                               minNeighbors=10,
                                                               minSize=(27, 27),
                                                               flags=cv2.CASCADE_SCALE_IMAGE)

            for (xCoordinateOfEye, yCoordinateOfEye, widthOfEye, heigthOfEye) in eyeCoordinate:
                faceAndEyeRectangles.append((xCoordinateOfFace + xCoordinateOfEye, yCoordinateOfFace + yCoordinateOfEye, xCoordinateOfFace + xCoordinateOfEye + widthOfEye, yCoordinateOfFace + yCoordinateOfEye + heigthOfEye))

        return faceAndEyeRectangles
