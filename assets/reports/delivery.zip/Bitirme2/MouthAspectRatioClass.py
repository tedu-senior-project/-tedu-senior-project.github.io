from scipy.spatial import distance as dist

def mouth_aspect_ratio(mouth):
	# compute the euclidean distances between the two sets of
	# vertical mouth landmarks (x, y)-coordinates
	A = dist.euclidean(mouth[2], mouth[9])
	B = dist.euclidean(mouth[4], mouth[7])
	C = dist.euclidean(mouth[0], mouth[6]) 
    
	# compute the mouth aspect ratio
	mar = (A + B) / (2.0 * C)
    
	# return the mouth aspect ratio
	return mar
