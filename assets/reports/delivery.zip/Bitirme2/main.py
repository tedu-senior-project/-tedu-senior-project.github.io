from imutils import face_utils
from threading import Thread
import numpy as np
import EyeAspectRatioClass
import MouthAspectRatioClass
from eye_tracker import EyeTracking
from joblib import dump, load
import playsound
import argparse
import time
import dlib
import cv2

Eye_AR_THRESH = 15
MOUTH_AR_THRESH = 0.71
alarm_sound = False

lStart=42
lEnd=48
rStart=36
rEnd=42

eye_tracker = EyeTracking( "haarcascade_frontalface_default.xml", "haarcascade_eye.xml")

# initialize dlib's face detector (HOG-based) and then create
dlib_detector = dlib.get_frontal_face_detector()
dlib_predictor = dlib.shape_predictor('shape_predictor_68_face_landmarks.dat')

# grab the indexes of the facial landmarks for the mouth
(mStart, mEnd) = (49, 68)

cap = cv2.VideoCapture(0)
time.sleep(1.0)

frame_width = 640
frame_height = 360
info_dict = {
    'current_frame': 0,
}

FrequencyOfYawning = 0

current_frame = 1


file = open("demofile.txt", "w")
string = "-------------------------------------------------------------"
file.write(string)

loaded = load('filename.joblib')

temp_ear = 0
temp_mouth = 0
temp_frequency = 0

def sound(path):
        playsound.playsound(path)

argParser = argparse.ArgumentParser()
argParser.add_argument("-a", "--alarm", type=str, default="alarm2.wav")
args = vars(argParser.parse_args())

# loop over frames from the video stream
while True:
    (grabbed, frame) = cap.read()    
    height = frame.shape[0]
    weight = frame.shape[1]
    frame = cv2.resize(frame, (500, int(500 * height / weight)))
    gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
    rects = dlib_detector(gray, 0)
    for rect in rects:
        shape = dlib_predictor(gray, rect)
        shape2 = dlib_predictor(gray, rect)

        shape2 = np.array([[p.x, p.y] for p in shape2.parts()])
        leftEye= shape2[lStart:lEnd]

        rightEye = shape2[rStart:rEnd]
        leftH, leftW, leftEAR= EyeAspectRatioClass.eye_aspect_ratio(leftEye)
        
        
        rightH, rightW, rightEAR = EyeAspectRatioClass.eye_aspect_ratio(rightEye)
        ear = (leftEAR + rightEAR) / 2.0

        leftEyeHull = cv2.convexHull(leftEye)

        rightEyeHull = cv2.convexHull(rightEye)
        
        H=(rightH+leftH)/2
        w=(rightW+leftW)/2 
        
        
        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)

        blue = (255, 0, 0) # rectangle color
        rectangles = eye_tracker.tracking(gray)
    
        thick = 1
        for rectangle in rectangles:
            x1, y1, x2, y2 = rectangle
            cv2.rectangle(frame, (x1, y1), (x2, y2), blue, thick)
        
        a = loaded.predict([[H,w,ear]])[0]
        
        if a == '1':
            temp_ear = temp_ear + 1
            if temp_ear > Eye_AR_THRESH:
                string_ear = "-EAR: " + str(ear) + " Height: " + str(H) + " Width: " + str(w)+ "\n"
                file.write(string_ear)
                cv2.putText(frame, "Eye is closed for a long time!", (30,150), cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0,0,255),2)

                if not alarm_sound:
                    alarm_sound= True
                    if True:
                        thrd = Thread(target=sound, args=(args["alarm"],))
                        thrd.deamon = True
                        thrd.start()

            elif a == '0':
                temp_ear = 0
                alarm_sound= False
        if a == '0':
            temp_ear = 0
            alarm_sound= False
            
        cv2.putText(frame, "Prediction: {}".format(loaded.predict([[H,w,ear]])), (300, 30),cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 0, 255), 2)
        cv2.putText(frame, "EAR: {:.2f}".format(ear), (300, 60),cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 0, 255), 2)

        
        shape = face_utils.shape_to_np(shape)
        mouth = shape[mStart:mEnd]
        mar = MouthAspectRatioClass.mouth_aspect_ratio(mouth)
        mouthHull = cv2.convexHull(mouth)
        cv2.drawContours(frame,[mouthHull],-1, (10,30,255),1)
        cv2.putText(frame,"MAR: {:.2f}".format(mar),(30,30),cv2.FONT_HERSHEY_SIMPLEX,0.7,(0,0,255),2)

        
        if mar > MOUTH_AR_THRESH:
            cv2.putText(frame, "Mouth is Open!", (30,60), cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0,0,255),2)
            temp_mouth = temp_mouth+1
            if temp_mouth>5:
                string_mouth = "-MAR: " + str(mar) + "\n"
                file.write(string_mouth)
                cv2.putText(frame, "Mouth is for a long time!", (30,90), cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0,0,255),2)
                

            if temp_mouth ==5:
                temp_frequency= temp_frequency+1
                print("temp_frequency: ", temp_frequency)
        elif mar<MOUTH_AR_THRESH:
            temp_mouth = 0
            if temp_frequency > 3 :
                cv2.putText(frame, "Frequency increase", (30,120), cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0,0,255),2)
            
    cv2.imshow("Frame",frame)
    key = cv2.waitKey(1) & 0xFF
    
    if key == ord("q"):
        break

cv2.destroyAllWindows()
cap.stop()
string = "-------------------------------------------------------------"
file.write(string)                
