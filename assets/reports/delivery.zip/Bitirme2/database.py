import psycopg2

connection = psycopg2.connect(database="postgres", user="postgres", password="gokceTEDU", host="localhost", port=5432)

cursor = connection.cursor()

cursor.execute("select * from supervisor;")
record = cursor.fetchall()
print("\nData: ", record)

cursor.execute("select * from userinformation;")
record2 = cursor.fetchall()
print("\nData: ", record2)

cursor.execute("select * from relativeinformation;")
record3 = cursor.fetchall()
print("\nData: ", record3)