from scipy.spatial import distance as dist

def eye_aspect_ratio(eye):
    string = ""
    # compute the euclidean distances between the two sets of
    # vertical eye landmarks (x, y)-coordinates
    A = dist.euclidean(eye[1], eye[5])
    B = dist.euclidean(eye[2], eye[4])
    
    h = A+B
    
    # compute the euclidean distance between the horizontal
    # eye landmark (x, y)-coordinates width
    C = dist.euclidean(eye[0], eye[3])
    
    # compute the eye aspect ratio
    ear = (A + B) / (2.0 * C)
    
    # return the eye aspect ratio
    string = str(h) + " "+str(C) + " "+str(ear)
    return h,C,ear
